# ==========================================================================
# Ancient Catacombs  --  hbs_relicfuse:catacombs
#
# Lore: a buried research complex where the ancients studied Ancient Crystals,
# hunting for the rare powered ones, and attempted the first fusions.
#
# Footprint: 32 x 32 (2x2 chunks), 6 blocks tall total (floor + 4 air + ceiling).
# Palette: Ancient City (deepslate family, sculk, soul lanterns, dark oak).
#
# Origin (~ ~ ~) = the NORTHWEST FLOOR corner. Builds toward +X (east),
# +Z (south) and +Y (up). Place the command block at the intended FLOOR level.
# ==========================================================================

scoreboard objectives add relic_rng dummy

# --- solid block of stone, rooms are carved out of it ---
fill ~ ~ ~ ~31 ~5 ~31 deepslate_bricks

# --- carve rooms ---
# central
fill ~11 ~1 ~11 ~20 ~4 ~20 air
# nw
fill ~3 ~1 ~3 ~9 ~4 ~9 air
# ne
fill ~22 ~1 ~3 ~28 ~4 ~9 air
# sw
fill ~3 ~1 ~22 ~9 ~4 ~28 air
# se
fill ~22 ~1 ~22 ~28 ~4 ~28 air

# --- carve corridors ---
fill ~14 ~1 ~1 ~17 ~4 ~30 air
fill ~1 ~1 ~14 ~30 ~4 ~17 air
fill ~9 ~1 ~5 ~14 ~4 ~7 air
fill ~17 ~1 ~5 ~22 ~4 ~7 air
fill ~9 ~1 ~24 ~14 ~4 ~26 air
fill ~17 ~1 ~24 ~22 ~4 ~26 air

# --- room floors: deepslate tiles ---
fill ~11 ~ ~11 ~20 ~ ~20 deepslate_tiles
fill ~3 ~ ~3 ~9 ~ ~9 deepslate_tiles
fill ~22 ~ ~3 ~28 ~ ~9 deepslate_tiles
fill ~3 ~ ~22 ~9 ~ ~28 deepslate_tiles
fill ~22 ~ ~22 ~28 ~ ~28 deepslate_tiles

# ====================== CENTRAL FUSION HALL ======================
# corner pillars
fill ~12 ~1 ~12 ~12 ~3 ~12 polished_deepslate
setblock ~12 ~4 ~12 chiseled_deepslate
fill ~19 ~1 ~12 ~19 ~3 ~12 polished_deepslate
setblock ~19 ~4 ~12 chiseled_deepslate
fill ~12 ~1 ~19 ~12 ~3 ~19 polished_deepslate
setblock ~12 ~4 ~19 chiseled_deepslate
fill ~19 ~1 ~19 ~19 ~3 ~19 polished_deepslate
setblock ~19 ~4 ~19 chiseled_deepslate

# the fusion altar -- reinforced deepslate platform, crystal on top
fill ~14 ~1 ~14 ~17 ~1 ~17 reinforced_deepslate
setblock ~15 ~2 ~15 sculk_catalyst
setblock ~16 ~2 ~15 amethyst_block
setblock ~15 ~2 ~16 chiseled_deepslate
setblock ~16 ~2 ~16 budding_amethyst
setblock ~16 ~3 ~16 amethyst_cluster[facing=up]
setblock ~15 ~3 ~15 soul_fire

# sculk creep around the altar
fill ~12 ~ ~13 ~13 ~ ~15 sculk replace deepslate_tiles
fill ~17 ~ ~17 ~19 ~ ~18 sculk replace deepslate_tiles
fill ~14 ~ ~12 ~16 ~ ~13 sculk replace deepslate_tiles
setblock ~13 ~1 ~13 sculk_shrieker[can_summon=true,shrieking=false]
setblock ~18 ~1 ~18 sculk_shrieker[can_summon=true,shrieking=false]
setblock ~13 ~1 ~18 sculk_sensor
setblock ~18 ~1 ~13 sculk_sensor
setblock ~12 ~1 ~14 sculk_vein[up=false,down=true]
setblock ~19 ~1 ~17 sculk_vein[up=false,down=true]

# brewing bench on the west side of the hall
setblock ~11 ~1 ~15 deepslate_tile_slab[type=top]
setblock ~11 ~1 ~16 deepslate_tile_slab[type=top]
setblock ~11 ~2 ~15 brewing_stand
setblock ~11 ~2 ~16 cauldron
setblock ~11 ~1 ~14 chiseled_deepslate

# supply chest, east side
setblock ~20 ~1 ~15 chest[facing=west]
data merge block ~20 ~1 ~15 {LootTable:"minecraft:chests/ancient_city"}

# ====================== NW LAB -- CRYSTAL ASSAY ======================
fill ~4 ~1 ~4 ~4 ~1 ~8 dark_oak_fence
fill ~4 ~2 ~4 ~4 ~2 ~8 dark_oak_slab[type=top]
setblock ~5 ~1 ~4 brewing_stand
setblock ~6 ~1 ~4 cauldron[level=3]
setblock ~7 ~1 ~4 chiseled_deepslate
setblock ~7 ~2 ~4 candle[candles=3,lit=true]
setblock ~5 ~1 ~8 budding_amethyst
setblock ~5 ~2 ~8 amethyst_cluster[facing=up]
setblock ~6 ~1 ~8 amethyst_block
setblock ~4 ~1 ~4 chest[facing=east]
data merge block ~4 ~1 ~4 {LootTable:"minecraft:chests/ancient_city"}
setblock ~8 ~1 ~6 lectern[facing=west,has_book=false]

# ====================== NE LAB -- CONTAINMENT ======================
# the specimen cell
fill ~24 ~1 ~4 ~26 ~1 ~6 reinforced_deepslate
fill ~24 ~2 ~4 ~26 ~3 ~4 iron_bars
fill ~24 ~2 ~6 ~26 ~3 ~6 iron_bars
fill ~24 ~2 ~5 ~24 ~3 ~5 iron_bars
fill ~26 ~2 ~5 ~26 ~3 ~5 iron_bars
setblock ~25 ~2 ~5 amethyst_block
setblock ~25 ~3 ~5 amethyst_cluster[facing=down]
# the shulker box -- sealed sample storage
setblock ~27 ~1 ~8 light_gray_shulker_box[facing=up]
setblock ~26 ~1 ~8 deepslate_tile_slab[type=top]
setblock ~23 ~1 ~8 chest[facing=north]
data merge block ~23 ~1 ~8 {LootTable:"minecraft:chests/ancient_city"}

# ====================== SW LAB -- RECORDS ======================
fill ~4 ~1 ~23 ~4 ~1 ~27 chiseled_bookshelf
setblock ~5 ~1 ~23 lectern[facing=east,has_book=false]
fill ~6 ~1 ~26 ~8 ~1 ~26 dark_oak_planks
setblock ~7 ~2 ~26 candle[candles=2,lit=true]
setblock ~8 ~1 ~23 gray_wool
setblock ~8 ~2 ~23 light_gray_carpet
setblock ~6 ~1 ~23 chest[facing=south]
data merge block ~6 ~1 ~23 {LootTable:"minecraft:chests/ancient_city"}

# ====================== SE LAB -- FUSION TEST CELL ======================
fill ~24 ~1 ~24 ~26 ~1 ~26 reinforced_deepslate
setblock ~25 ~2 ~25 chiseled_deepslate
setblock ~25 ~3 ~25 soul_fire
setblock ~24 ~2 ~24 polished_deepslate_wall
setblock ~26 ~2 ~26 polished_deepslate_wall
setblock ~23 ~1 ~27 sculk_catalyst
fill ~22 ~ ~26 ~24 ~ ~28 sculk replace deepslate_tiles
setblock ~28 ~1 ~23 sculk_shrieker[can_summon=true,shrieking=false]

# --- RARE: ender chest, roughly a 1-in-8 chance ---
execute store result score #roll relic_rng run random value 1..8
execute if score #roll relic_rng matches 1 run setblock ~27 ~1 ~27 ender_chest[facing=west]
execute unless score #roll relic_rng matches 1 run setblock ~27 ~1 ~27 chiseled_deepslate
execute unless score #roll relic_rng matches 1 run setblock ~27 ~2 ~27 candle[candles=1,lit=true]

# ====================== LIGHTING ======================
setblock ~6 ~4 ~6 soul_lantern[hanging=true]
setblock ~25 ~4 ~6 soul_lantern[hanging=true]
setblock ~6 ~4 ~25 soul_lantern[hanging=true]
setblock ~25 ~4 ~25 soul_lantern[hanging=true]
setblock ~15 ~4 ~8 soul_lantern[hanging=true]
setblock ~16 ~4 ~23 soul_lantern[hanging=true]
setblock ~8 ~4 ~15 soul_lantern[hanging=true]
setblock ~23 ~4 ~16 soul_lantern[hanging=true]
setblock ~13 ~4 ~15 soul_lantern[hanging=true]
setblock ~18 ~4 ~16 soul_lantern[hanging=true]
setblock ~15 ~4 ~3 soul_lantern[hanging=true]
setblock ~15 ~4 ~29 soul_lantern[hanging=true]
setblock ~3 ~4 ~15 soul_lantern[hanging=true]
setblock ~29 ~4 ~15 soul_lantern[hanging=true]

# ====================== AGE AND DECAY ======================
setblock ~4 ~ ~5 cracked_deepslate_bricks
setblock ~5 ~ ~15 cracked_deepslate_tiles
setblock ~6 ~ ~17 cracked_deepslate_bricks
setblock ~6 ~ ~24 deepslate_tiles
setblock ~7 ~ ~7 cracked_deepslate_tiles
setblock ~7 ~ ~14 deepslate_tiles
setblock ~7 ~ ~15 cracked_deepslate_bricks
setblock ~7 ~ ~17 deepslate_tiles
setblock ~7 ~ ~27 deepslate_tiles
setblock ~8 ~ ~17 cracked_deepslate_bricks
setblock ~9 ~ ~17 cracked_deepslate_bricks
setblock ~11 ~ ~14 cracked_deepslate_tiles
setblock ~12 ~ ~13 deepslate_tiles
setblock ~12 ~ ~15 deepslate_tiles
setblock ~12 ~ ~20 cracked_deepslate_bricks
setblock ~13 ~ ~5 cracked_deepslate_tiles
setblock ~14 ~ ~30 cracked_deepslate_tiles
setblock ~16 ~ ~10 cracked_deepslate_tiles
setblock ~20 ~ ~18 cracked_deepslate_tiles
setblock ~22 ~ ~25 cracked_deepslate_tiles
setblock ~22 ~ ~26 cracked_deepslate_bricks
setblock ~24 ~ ~24 cracked_deepslate_bricks
setblock ~28 ~ ~7 cracked_deepslate_bricks
setblock ~28 ~ ~8 cracked_deepslate_tiles

# ceiling damage
setblock ~5 ~5 ~5 cracked_deepslate_bricks
setblock ~5 ~5 ~6 polished_deepslate
setblock ~7 ~5 ~4 cracked_deepslate_bricks
setblock ~14 ~5 ~2 cracked_deepslate_bricks
setblock ~14 ~5 ~20 cracked_deepslate_tiles
setblock ~15 ~5 ~4 cracked_deepslate_bricks
setblock ~17 ~5 ~2 polished_deepslate
setblock ~17 ~5 ~4 cracked_deepslate_bricks
setblock ~17 ~5 ~10 polished_deepslate
setblock ~17 ~5 ~30 polished_deepslate
setblock ~20 ~5 ~20 cracked_deepslate_bricks
setblock ~22 ~5 ~8 cracked_deepslate_tiles
setblock ~23 ~5 ~3 cracked_deepslate_bricks
setblock ~26 ~5 ~5 cracked_deepslate_bricks
setblock ~26 ~5 ~15 cracked_deepslate_bricks
setblock ~27 ~5 ~25 cracked_deepslate_tiles

# fallen rubble
setblock ~3 ~1 ~14 deepslate_brick_wall
setblock ~22 ~1 ~17 cobbled_deepslate
setblock ~23 ~1 ~24 deepslate_brick_slab[type=bottom]
setblock ~23 ~1 ~28 deepslate_brick_slab[type=bottom]
setblock ~24 ~1 ~3 deepslate_brick_wall
setblock ~24 ~1 ~6 deepslate_brick_slab[type=bottom]

# --- doorway trim on the four connector mouths ---
setblock ~9 ~4 ~6 deepslate_tile_stairs[facing=east,half=top]
setblock ~22 ~4 ~6 deepslate_tile_stairs[facing=west,half=top]
setblock ~9 ~4 ~25 deepslate_tile_stairs[facing=east,half=top]
setblock ~22 ~4 ~25 deepslate_tile_stairs[facing=west,half=top]

# --- clear the altar space in case rubble landed on it ---
fill ~14 ~2 ~14 ~17 ~4 ~17 air replace #minecraft:slabs

say [hbs_relicfuse] Ancient Catacombs placed. 32x32, 6 tall.
